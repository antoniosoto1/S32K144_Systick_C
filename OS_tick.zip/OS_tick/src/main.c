/*
 * main implementation: use this 'C' sample to create your own application
 *
 */


#include "S32K144.h" /* include peripheral declarations S32K144 */

void EnableInterrupts(void);  // Enable interrupts
void WaitForInterrupt(void);
volatile unsigned long Counts = 0;

void PORT_init (void) {
  PCC-> PCCn[PCC_PORTD_INDEX] = PCC_PCCn_CGC_MASK; /* Enable clock for PORT D */
  PTD->PDDR |= 1<<0;            /* Port D0:  Data Direction= output */
  PORTD->PCR[0] =  0x00000100;  /* Port D0:  MUX = ALT1, GPIO (to blue LED on EVB) */
}

void WDOG_disable (void){
  WDOG->CNT=0xD928C520; 	/*Unlock watchdog*/
  WDOG->TOVAL=0x0000FFFF;	/*Maximum timeout value*/
  WDOG->CS = 0x00002100;    /*Disable watchdog*/
}


// SysTick Init with busy wait running at FIRC CLOCK.
void SysTick_Init(unsigned long period){
  S32_SysTick->CSR = 0;                   // disable SysTick during setup
  S32_SysTick->RVR = period-1;  		// Reload value
  S32_SysTick->CVR = 0;                // any write to current clears it

  S32_SCB->SHPR3= (S32_SCB->SHPR3 &0x00FFFFFF)|0x40000000;
  S32_SysTick->CSR = 0x07; // CLKSOURCE =1 processor clock source, TICKINT=1 counting down to zero asserts Systick exception,
  	  	  	  	  	  	   // ENABLE= 1 counter enabled.
  EnableInterrupts();
}

void SysTick_Handler(void){
  PTD->PTOR |= 1<<0;                /* Toggle PD0 (LED blue) */
  Counts = Counts + 1;
}


int main(void)
{
	WDOG_disable();

	PORT_init ();

	SysTick_Init(16000000);        // SysTick timer Init

	EnableInterrupts();


	  while(1){                   // interrupts every 1ms, 500 Hz flash
	    WaitForInterrupt();
	  }

    /* to avoid the warning message for GHS and IAR: statement is unreachable*/
#if defined (__ghs__)
#pragma ghs nowarning 111
#endif
#if defined (__ICCARM__)
#pragma diag_suppress=Pe111
#endif
	return 0;
}
